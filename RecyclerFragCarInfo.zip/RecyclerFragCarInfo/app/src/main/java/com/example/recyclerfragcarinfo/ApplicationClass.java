package com.example.recyclerfragcarinfo;

import android.app.Application;

import java.util.ArrayList;

public class ApplicationClass extends Application {
    public static ArrayList<Car> cars;

    @Override
    public void onCreate() {
        super.onCreate();

        cars = new ArrayList<Car>();
        cars.add(new Car("Volkswagen", "Polo", "Jatin Joshi", "394848393"));
        cars.add(new Car("Mercedes", "Benz", "snfsdjk djskd", "394834343"));
        cars.add(new Car("Nissan", "Sunny", "Harry Potter", "39400000"));
        cars.add(new Car("Volkswagen", "E123", "Lukas Gram", "394995963"));
        cars.add(new Car("Mercedes", "sjkdnds", "Tylor Swift", "34343493"));
        cars.add(new Car("Nissan", "Pulsur", "Jatin Joshi", "43348393"));
    }
}
